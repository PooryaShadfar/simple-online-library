     <head>  
		   <script src="../ol-apperance/js/edit.js"></script>  
      </head>  
           <div class="container">   
                <div class="table-responsive">  
			    <div class="form-group">  
                     <div class="input-group">  
                          <span class="input-group-addon">Search...</span>  
                          <input type="text" name="search_text" id="search_text" placeholder="Search by bookname!" class="form-control" />  
                     </div>  
                </div>  
                <br/>
                <div id="result"></div>  
                   <div id="live_data"></div>			   
           </div>  
		   </div>   