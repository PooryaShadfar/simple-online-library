<footer>
	<div id="footer-wrapper">
		<div id="footer">
		</div>
	</div>
		<div id="footer-copy"><div class="container"><div class="row">
	<span class="footer-bottom-sp pull-left"><p> طراحی شده با <i style="color:red;"class="fa fa-heart faa-pulse animated"></i> توسط <a href="http://pgraph.ir/" target="_blank">
	<img style="width: 65px;"src="ol-apperance/image/pg-logo.png" alt="Pgraph" /></a></p></span></div></div>
		</div>
</footer>
</body>
</html>