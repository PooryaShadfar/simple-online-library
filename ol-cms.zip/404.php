<?php include_once("header.php"); ?>
<section id="firstCase" class="sepratorContains"><div class="container"><div class="row">
<div class="titlebar"><h4><i class="fa fa-warning" aria-hidden="true"></i> 404 پیدا نشد  </h4></div>
<h3>برگه مورد نظر شما یافت نشد</h3>
<h4>لطفا به صفحه اصلی بازگردید و یا وارد حساب کاربری خود شوید.</h4>
</div></div></section><div style="margin-bottom:30em;"></div>
<?php include_once("footer.php"); ?>