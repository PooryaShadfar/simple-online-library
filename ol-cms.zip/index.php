<?php require_once("config.php"); ?>
<?php include_once("header.php"); ?>
<section id="firstCase" class="sepratorContains"><div class="container"><div class="row">
<div class="titlebar"><h4><i class="fa fa-book"></i> آخرین کتاب ها  </h4></div>
<div class="col-md-12 centerLayout">
<?php include('show-posts.php' ); ?>
</div>
</div></div></section></br>
<?php include_once("footer.php"); ?>